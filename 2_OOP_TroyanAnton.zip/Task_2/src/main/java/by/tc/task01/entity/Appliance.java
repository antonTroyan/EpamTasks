package by.tc.task01.entity;

public class Appliance {
	// you may add your own code here
}
