package by.tc.task01.main;

import by.tc.task01.entity.Appliance;

public class PrintApplianceInfo {
	
	public static void print(Appliance appliance) {
		System.out.println(appliance);

	}
	
	// you may add your own code here

}
